# 🚀 GitHub Archive Google BigQuery API  

An API to fetch and filter GitHub Archive data from Google BigQuery with powerful filtering, pagination, and sorting options.  

## 🌟 Features  
- Retrieve all GitHub Archive data  
- Apply various filters like email domain, region, year, and event type  
- Support for pagination and sorting  
- Optimized for performance  

---

## 📌 API Endpoints  

### Get All Data  

```GET @ /getAllData``` return all the data with the pagination feature

### Get filtered data
```GET @ /filteredData?emailDomain=coinbase.com&region=US&eventType=PushEvent&page=1&limit=1&sortBy=created_at&year=2015-2019&year=2015``` return all the filtered data.

## ⚙️ Setup & Usage
### 🔧 Requirements
#### Node.js (if applicable)
#### Google BigQuery access


## Installation
``` git clone https://github.com/Rajs2001/googleBigqueryGHArchive.git```
```cd googleBigqueryGHArchive```
```npm install```
```npm run dev```

## 📜 License
#### This project is open-source under the MIT License.

## 🏢 About the Company  

**Techserve nexus pvt. ltd.** is dedicated to building high-performance web and mobile app solutions. We are also specialize in Big Data, cloud computing, and API development to help businesses unlock insights from vast datasets efficiently.  

🔹 **Website:** [www.techservenexus.com](https://www.techservenexus.com)  
🔹 **Email:** [contact@techservenexus.com](mailto:contact@techservenexus.com)  
🔹 **GitHub:** [github.com/techservenexus](https://github.com/Techserve-Nexus)

For queries, collaborations, or support, feel free to reach out!