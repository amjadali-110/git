const express = require('express');
const { BigQuery } = require('@google-cloud/bigquery');
require("dotenv").config();
const app = express();
const PORT = 3000;

const CUSTOM_TOKEN = "RajeshIsGreat";

// process.env.GOOGLE_APPLICATION_CREDENTIALS = './hip-informatics-446120-b8-f5da7d69041c.json';
process.env.GOOGLE_APPLICATION_CREDENTIALS = './serviceacc2.json';

const bigquery = new BigQuery();

app.get("/", (req, res) => {
    res.status(200).json({
        message: "It works!!"
    });
});

app.get('/getAllData', async (req, res) => {
    const { page = 1, limit = 25 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    try {
        const years = Array.from({ length: 10 }, (_, i) => 2015 + i);

        const dataQuery = years.map(year => `
            SELECT * 
            FROM \`githubarchive.year.${year}\` 
        `).join(" UNION ALL ");

        const finalQuery = `
            SELECT * 
            FROM (
                ${dataQuery}
            )
            LIMIT ${limit} OFFSET ${offset}
        `;

        const [rows] = await bigquery.query({ query: finalQuery, location: 'US' });

        const countQueries = years.map(year =>
            `SELECT COUNT(*) AS totalRows FROM \`githubarchive.year.${year}\``
        );

        const countResults = await Promise.all(
            countQueries.map(query => bigquery.query({ query, location: 'US' }))
        );

        const totalRows = countResults.reduce(
            (sum, [result]) => sum + parseInt(result[0].totalRows, 10),
            0
        );

        const totalPage = Math.ceil(totalRows / limit);

        res.json({
            success: true,
            message: `Found data on server on US location`,
            currentPage: parseInt(page),
            totalPage,
            totalRows,
            countPerPage: limit,
            data: rows
        });
    } catch (error) {
        console.error('Error querying BigQuery:', error);
        res.status(500).json({ error: 'Internal server error', details: error.message });
    }
});

app.get("/filteredData", async (req, res) => {
    let { year, region = "US", eventType, emailDomain, page = 1, limit = 25, sortBy = "created_at" } = req.query;
    page = parseInt(page);
    limit = parseInt(limit);
    const offset = (page - 1) * limit;

    try {
        let years = [];
        if (year) {
            if (year.includes("-")) {
                const [start, end] = year.split("-").map(y => parseInt(y));
                years = Array.from({ length: end - start + 1 }, (_, i) => start + i);
            } else {
                years = [parseInt(year)];
            }
        } else {
            years = Array.from({ length: 10 }, (_, i) => 2015 + i);
        }

        let whereClauses = [];
        if (eventType) whereClauses.push(`type = '${eventType}'`);
        if (emailDomain) {
            whereClauses.push(`REGEXP_CONTAINS(JSON_EXTRACT(payload, "$.commits"), r'\\"email\\":\\"[^@]+@${emailDomain}\\"')`);
        }
        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

        const dataQuery = years.map(year => `
            SELECT * FROM \`githubarchive.year.${year}\`
            ${whereClause}
        `).join(" UNION ALL ");

        const finalQuery = `
            SELECT * FROM (
                ${dataQuery}
            )
            ORDER BY ${sortBy} DESC
            LIMIT ${limit} OFFSET ${offset}
        `;

        const [rows] = await bigquery.query({ query: finalQuery, location: region });

        const countQueries = years.map(year =>
            `SELECT COUNT(*) AS totalRows FROM \`githubarchive.year.${year}\` ${whereClause}`
        );
        const countResults = await Promise.all(countQueries.map(query => bigquery.query({ query, location: region })));
        const totalRows = countResults.reduce((sum, [result]) => sum + parseInt(result[0]?.totalRows || 0, 10), 0);

        const totalPage = Math.ceil(totalRows / limit);

        res.json({
            success: true,
            message: "Filtered data retrieved successfully",
            currentPage: page,
            totalPage,
            totalRows,
            countPerPage: limit,
            data: rows
        });
    } catch (error) {
        console.error("Error querying BigQuery:", error);
        res.status(500).json({ error: "Internal server error", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
